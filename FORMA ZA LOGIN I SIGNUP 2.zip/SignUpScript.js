function SignUpFunction()
{
  window.location="SignUp.html";
}
